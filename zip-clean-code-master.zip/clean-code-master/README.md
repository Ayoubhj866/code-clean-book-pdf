# A Handbook of Agile Software Craftsmanship
1. Meaningful Names
2. Functions
3. Comments
